function res = normalise(a)
res = a;