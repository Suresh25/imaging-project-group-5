function res = property(a)
res = a;