function res = classification(a)
res = a;