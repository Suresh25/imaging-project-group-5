function res = labeling(a)
res = a;