function res = count(a)
res = a;