function videoObject = videoLoader(videoFile)

videoObject = VideoReader(videoFile);
%get(videoObject);