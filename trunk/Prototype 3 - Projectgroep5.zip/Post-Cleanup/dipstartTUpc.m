addpath('C:\Program Files\DIPimage 2.2\common\dipimage');
dip_initialise;
dipsetpref('ImageFilePath', 'C:\Program Files\DIPimage 2.2\images');
