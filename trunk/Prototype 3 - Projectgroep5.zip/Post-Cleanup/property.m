% labeling(img, gui_handle)
% img = Segmented DIPImage with persons labeled
% gui_handle = the handles of the GUI.
% Returns: Int array of length 2. First element is the # of persons in
%          the lift. Second element is the # of persons out the lift
function res = property(a)
res = a;